package com.example.healthcheckwebused;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Results extends AppCompatActivity {

    TextView res_conc;
    TextView res_des;
    ImageView res;
    ImageView errimg;
    String[] credentials;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        res_conc = findViewById(R.id.result_conclusion);
        res_des = findViewById(R.id.results_description);

        res = findViewById(R.id.fatigue_level_img);
        errimg = findViewById(R.id.fortunes_img);

        Intent intent = getIntent();

        credentials = intent.getStringArrayExtra("credentials");
        String first_value = intent.getStringExtra("first_value");
        String second_value = intent.getStringExtra("second_value");

        String data = String.format("day=15&month=12&year=1990&sex=1&m1=%s&m2=%s",
                first_value, second_value);

        try {
            datasender(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void datasender(String data) throws IOException {

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(mediaType, data);

        Request request = new Request.Builder()
                .url("http://abashin.ru/cgi-bin/ru/tests/burnout")
                .method("POST", body)
                .addHeader("Host", "abashin.ru")
                .addHeader("Connection", "close")
                .addHeader("Cache-Control", "max-age=0")
                .addHeader("DNT", "1")
                .addHeader("Upgrade-Insecure-Requests", "1")
                .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;" +
                        "q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
                .addHeader("Accept-Encoding", "deflate")
                .addHeader("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7")
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Content-Length", "43")
                .build();

        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                if (response.isSuccessful()) {

                    String message = response.body().string();

                    Document html_response = Jsoup.parse(message);
                    String format_message = html_response.text();

                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            res_des.setText(format_message);

                            if (format_message.contains("отсутствию")) {
                                res_Awe();

                            } else if (format_message.contains("небольшому")) {
                                res_Good();

                            } else if (format_message.contains("высокому")) {
                                res_Bad();

                            } else if (format_message.contains("Error")) {
                                res_Wor();
                            }
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void res_Awe() {
        res_conc.setText("В соответствии с введенными данными у Вас переутомления не выявлено.");
        errimg.setVisibility(View.VISIBLE);
        errimg.setImageResource(R.drawable.logo);
        errimg.setBackgroundColor(Color.argb(100, 0, 255, 0));
        res.setVisibility(View.VISIBLE);
        res.setImageResource(R.drawable.lvl_max);



    }

    public void res_Good() {
        res_conc.setText("В соответствии с введенными данными у Вас было выявлено небольшое переутомление. Вам необходимо отдохнуть и проконсультироваться с врачем.");
        errimg.setVisibility(View.VISIBLE);
        errimg.setImageResource(R.drawable.logo);
        errimg.setBackgroundColor(Color.argb(100, 255, 0, 255));
        res.setVisibility(View.VISIBLE);
        res.setImageResource(R.drawable.lvl_good);
    }

    public void res_Bad() {
        res_conc.setText("В соответствии с введенными данными у Вас было выявлено переутомление. Вам необходимо отдохнуть и вызвать врача.");
        errimg.setVisibility(View.VISIBLE);
        errimg.setImageResource(R.drawable.logo);
        errimg.setBackgroundColor(Color.argb(100, 255, 255, 0));
        res.setVisibility(View.VISIBLE);
        res.setImageResource(R.drawable.lvl_low);
    }

    public void res_Wor() {
        res_conc.setText("В соответствии с введенными данными у Вас было выявлено сильнейшее переутомление. Вам необходимо немедленно вызвать врача!");
        errimg.setVisibility(View.VISIBLE);
        errimg.setImageResource(R.drawable.logo);
        errimg.setBackgroundColor(Color.argb(100, 255, 0, 0));
        res.setVisibility(View.VISIBLE);
        res.setImageResource(R.drawable.lvl_vlow);
    }
}
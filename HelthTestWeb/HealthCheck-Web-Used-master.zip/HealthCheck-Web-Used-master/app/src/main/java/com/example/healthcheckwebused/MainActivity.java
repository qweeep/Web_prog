package com.example.healthcheckwebused;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormatSymbols;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Spinner bornyear_sp;
    Spinner bornmonth_sp;
    Spinner bornday_sp;
    Spinner gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bornyear_sp = findViewById(R.id.bornyear_spinner);
        bornmonth_sp = findViewById(R.id.bornmonth_spinner);
        bornday_sp = findViewById(R.id.bornday_spinner);
        gender = findViewById(R.id.gender_spinner);

        // Выпадающее меню
        String[] born_year = new String[200];
        int start_y = 2021;
        for (int i=0; i < 200; i++) {
            born_year[i] = String.valueOf(start_y - i);
        }

        String[] born_months = new String[12];
        for (int j=0; j < 12; j++) {
            born_months[j] = String.valueOf(getMonthForInt(j));
        }

        String[] born_day = new String[31];
        for (int n=0; n < 31; n++) {
            born_day[n] = String.valueOf(n + 1);
        }

        String[] genders = {"М", "Ж"};


        ArrayAdapter<String> spinnerArrayYears = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, born_year);
        ArrayAdapter<String> spinnerArrayMonths = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, born_months);
        ArrayAdapter<String> spinnerArrayDays = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, born_day);
        ArrayAdapter<String> spinnerArrayGenders = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, genders);

        spinnerArrayYears.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerArrayMonths.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerArrayDays.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerArrayGenders.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        bornyear_sp.setAdapter(spinnerArrayYears);
        bornmonth_sp.setAdapter(spinnerArrayMonths);
        bornday_sp.setAdapter(spinnerArrayDays);
        gender.setAdapter(spinnerArrayGenders);
    }

    public void ShowResults (View v) {
        EditText ques_three = findViewById(R.id.pulse_lie);
        EditText ques_six = findViewById(R.id.pulse_stand);
        Intent intent = new Intent(this, Results.class);

        String[] person_credentials = {
                bornday_sp.getSelectedItem().toString(),
                bornmonth_sp.getSelectedItem().toString(),
                bornyear_sp.getSelectedItem().toString(),
                gender.getSelectedItem().toString()};

        if (ques_three.getText().length() > 0 && ques_six.getText().length() > 0){
            String pulse_lie = ques_three.getText().toString();
            String pulse_stand = ques_six.getText().toString();
            intent.putExtra("first_value", pulse_lie);
            intent.putExtra("second_value", pulse_stand);
        }

        intent.putExtra("credentials", person_credentials);
        startActivity(intent);
    }

    String getMonthForInt(int num) {
        String month = "";
        DateFormatSymbols dfs = new DateFormatSymbols(new Locale("ru"));
        String[] months = dfs.getMonths();
        if (num >= 0 && num <= 11 ) {
            month = months[num];
        }
        return month;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        menu.setGroupVisible(R.id.group_new_game, false);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.exit_topic) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}